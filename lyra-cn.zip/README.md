# @xieyezi/lyra-cn

a tool for offline search Chinese.


- @lyrasearch/lyra
- pinyin
